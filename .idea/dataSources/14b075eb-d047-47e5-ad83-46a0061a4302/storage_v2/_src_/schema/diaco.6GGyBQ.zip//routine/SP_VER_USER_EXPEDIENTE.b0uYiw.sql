create
    definer = root@localhost procedure SP_VER_USER_EXPEDIENTE(IN EXP varchar(50))
BEGIN
SELECT exp.ncomercial,exp.observaciones,exp.expediente,
		 user.usuario as Usuario, jur.nombre as Juridico
	 FROM expjuridico exp 
	 INNER JOIN usuarios user 
	 ON exp.usuario = user.ID 
	 INNER JOIN juridicos jur
	 ON exp.id_juridicos = jur.id_juridicos OR
	 	jur.id_juridicos = 1
	 WHERE exp.expediente = EXP;
END;

