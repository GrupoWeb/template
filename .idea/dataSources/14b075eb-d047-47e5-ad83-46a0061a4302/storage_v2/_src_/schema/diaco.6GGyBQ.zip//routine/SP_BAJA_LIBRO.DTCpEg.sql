create
    definer = root@localhost procedure SP_BAJA_LIBRO(IN Resolucion varchar(50))
BEGIN
  UPDATE empresa R SET R.id_status = 6 WHERE R.resolucion = Resolucion;
END;

