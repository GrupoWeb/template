create
    definer = root@localhost procedure SP_VER_EXPEDIENTE(IN id varchar(50), IN NConsulta varchar(50))
BEGIN
SELECT DISTINCT x.expediente,x.ncomercial,x.nempresa,
	if (j.nombre = 'AccessFull',NConsulta,j.nombre) as Juridico
FROM expjuridico x
INNER JOIN juridicos j ON
	x.id_juridicos = j.id_juridicos
	OR j.id_juridicos = 1
WHERE  
x.expediente LIKE  id
AND x.id_texpj = 2;
END;

