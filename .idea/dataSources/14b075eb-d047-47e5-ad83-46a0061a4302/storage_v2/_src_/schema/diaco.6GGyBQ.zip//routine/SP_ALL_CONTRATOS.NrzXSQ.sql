create
    definer = root@localhost procedure SP_ALL_CONTRATOS()
BEGIN
select c.registro,concat(right(c.fecha,2),'/',month(c.fecha),'/',year(c.fecha)) AS fecha ,
REPLACE(REPLACE(c.ncomercial,char(92),''),char(34),'') AS consumidor,r.nombre_r AS sede
from contratos c, regional r WHERE  c.id_regional = r.id_regional 
AND c.status =  1 AND c.centinela <> 1 order by c.id_regional desc;
END;

